const nodemailer = require('nodemailer');

const sendNotification = async (
  organizerEmail,
  organizerName,
  organizerRole,
  eventName,
  startTime,
  endTime
) => {
  const transporter = nodemailer.createTransport({
    service: 'gmail', // You can use other services like SendGrid or SMTP providers
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASS,
    },
  });

  const mailOptions = {
    from: process.env.EMAIL_USER,
    to: organizerEmail,
    subject: `🔔 Event Organizer Assignment - ${eventName}`,
    html: `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>Event Organizer Assignment</title>
        <style>
          /* Reset styles */
          body, p, h1, h2, h3, h4, h5, h6 {
            margin: 0;
            padding: 0;
          }
          body {
            background-color: #e6f0ff; /* Light blue background for light mode */
            font-family: 'Arial, sans-serif';
            line-height: 1.6;
            color: #333333;
          }
          .container {
            width: 100%;
            max-width: 600px;
            margin: 20px auto;
            background-color: #ffffff;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
          }
          .header {
            background-color: #003366; /* Dark blue background */
            color: #ffffff;
            padding: 20px;
            text-align: center;
          }
          .header img {
            max-width: 100px;
            margin-bottom: 10px;
          }
          .content {
            padding: 20px;
          }
          .content h2 {
            color: #003366; /* Dark blue for headings */
            margin-bottom: 10px;
          }
          .details {
            margin: 20px 0;
          }
          .details p {
            margin-bottom: 10px;
          }
          .footer {
            background-color: #e6f0ff; /* Light blue background for footer */
            color: #555555;
            text-align: center;
            padding: 10px;
            font-size: 12px;
          }
          @media (prefers-color-scheme: dark) {
            body {
              background-color: #121212; /* Dark background for dark mode */
              color: #e0e0e0;
            }
            .container {
              background-color: #1e1e1e;
            }
            .header {
              background-color: #003366; /* Maintain dark blue for header */
              color: #ffffff;
            }
            .content h2 {
              color: #66b2ff; /* Lighter blue for headings in dark mode */
            }
            .footer {
              background-color: #1e1e1e;
              color: #bbbbbb;
            }
          }
          @media only screen and (max-width: 600px) {
            .container {
              width: 100%;
            }
            .header img {
              max-width: 80px;
            }
          }
        </style>
      </head>
      <body>
        <div class="container">
          <!-- Header -->
          <div class="header">
            <img src="https://i.ibb.co/VSFsMF6/Melodymesh.png" alt="Melodymesh Logo">
            <h1>New Organizer Assignment</h1>
          </div>

          <!-- Content -->
          <div class="content">
            <h2>Hello ${organizerName},</h2>
            <p>
              We are pleased to inform you that you have been assigned the role of <strong>"${organizerRole}"</strong> for the event <strong>${eventName}</strong>.
            </p>

            <div class="details">
              <p><strong>Event Name:</strong> ${eventName}</p>
              <p><strong>Role:</strong> ${organizerRole}</p>
              <p><strong>Time Slot:</strong></p>
              <p>
                <strong>Start:</strong> ${new Date(startTime).toLocaleString()}<br>
                <strong>End:</strong> ${new Date(endTime).toLocaleString()}
              </p>
            </div>

            <p>
              Please ensure you arrive on time and are prepared for your responsibilities. If you have any questions or need further assistance, feel free to reach out to us.
            </p>
          </div>

          <!-- Footer -->
          <div class="footer">
            <p>&copy; ${new Date().getFullYear()} Melodymesh Team. All rights reserved.</p>
            <p>If you did not expect this email, please contact us immediately.</p>
          </div>
        </div>
      </body>
      </html>
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    console.log(`Notification sent to ${organizerEmail}`);
  } catch (error) {
    console.error('Error sending notification:', error);
    throw error; // Propagate the error for further handling if needed
  }
};

module.exports = sendNotification;
