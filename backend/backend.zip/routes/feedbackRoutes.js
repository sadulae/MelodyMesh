const express = require('express');
const router = express.Router();
const feedbackController = require('../controllers/feedbackController'); // Ensure this path is correct

const { adminAuthMiddleware } = require('../middleware/authMiddleware'); // Assuming this middleware exists

// Get all feedback (Admin only)
router.get('/admin/all-feedback', adminAuthMiddleware, feedbackController.getAllFeedback);

// Get feedback by event (Admin only)
router.get('/admin/event-feedback/:eventId', adminAuthMiddleware, feedbackController.getFeedbackByEvent);

module.exports = router;
