const Feedback = require('../models/Feedback');

// Get all feedback (Admin route)
exports.getAllFeedback = async (req, res) => {
  try {
    const feedback = await Feedback.find().populate('eventId', 'title'); // Populating event title
    res.status(200).json(feedback);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching feedback', error });
  }
};

// Get feedback for a specific event
exports.getFeedbackByEvent = async (req, res) => {
  const { eventId } = req.params;
  try {
    const feedback = await Feedback.find({ eventId }).populate('eventId', 'title');
    if (!feedback) {
      return res.status(404).json({ message: 'No feedback found for this event' });
    }
    res.status(200).json(feedback);
  } catch (error) {
    res.status(500).json({ message: 'Error fetching feedback for event', error });
  }
};
